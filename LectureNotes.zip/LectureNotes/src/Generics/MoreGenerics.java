package Generics;

public class MoreGenerics {
}
