package Step8;

public class Person {
    public String speak (){
        return "Hello world";
    }
}
